import tensorflow as tf

a = [1,2,3,4,5,6]
print(a[-3:])